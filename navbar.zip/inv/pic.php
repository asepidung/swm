<?php
session_start();
if (!isset($_SESSION['login'])) {
   header("location: verifications/login.php");
}
require "../konak/conn.php";
require "terbilang.php";
$idinvoice = $_GET['idinvoice'];
$idusers = $_SESSION['idusers'];

// Tampilkan data dari tabel invoice
$query_invoice = "SELECT invoice.*, doreceipt.deliverydate, doreceipt.alamat, customers.nama_customer, segment.banksegment, segment.accname, segment.accnumber 
                  FROM invoice 
                  INNER JOIN doreceipt ON invoice.iddoreceipt = doreceipt.iddoreceipt 
                  INNER JOIN customers ON invoice.idcustomer = customers.idcustomer 
                  INNER JOIN segment ON customers.idsegment = segment.idsegment
                  WHERE invoice.idinvoice = '$idinvoice'";

$result_invoice = mysqli_query($conn, $query_invoice);
$row_invoice = mysqli_fetch_assoc($result_invoice);

// Tampilkan data dari tabel invoicedetail
$query_invoicedetail = "SELECT invoicedetail.*, barang.nmbarang 
                        FROM invoicedetail 
                        INNER JOIN barang ON invoicedetail.idbarang = barang.idbarang 
                        WHERE idinvoice = '$idinvoice'";
$result_invoicedetail = mysqli_query($conn, $query_invoicedetail);

$balance = $row_invoice['balance'];
$terbilang = terbilang($balance);

// Mendapatkan nilai dari tabel segment berdasarkan nmcustomer
$banksegment = $row_invoice['banksegment'];
$accname = $row_invoice['accname'];
$accnumber = $row_invoice['accnumber'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="widtd=device-widtd, initial-scale=1">
   <title>SWM Welcome</title>
   <link rel="icon" href="../dist/img/favicon.png" type="image/x-icon">
   <link rel="stylesheet" href="../https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
   <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
   <link rel="stylesheet" href="../https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
   <link rel="stylesheet" href="../plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
   <link rel="stylesheet" href="../plugins/icheck-bootstrap/icheck-bootstrap.min.css">
   <link rel="stylesheet" href="../plugins/jqvmap/jqvmap.min.css">
   <link rel="stylesheet" href="../dist/css/adminlte.min.css">
   <link rel="stylesheet" href="../plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
   <link rel="stylesheet" href="../plugins/daterangepicker/daterangepicker.css">
   <link rel="stylesheet" href="../plugins/summernote/summernote-bs4.min.css">
   <style>
      .mt-0 {
         margin: 0 0 0 0;
      }

      .floatingButton {
         position: fixed;
         top: 20px;
         right: 20px;
         z-index: 9999;
      }

      /* Media query untuk tampilan cetak */
      @media print {
         .floatingButton {
            display: none;
         }
      }
   </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
   <button class="btn bg-gradient-warning floatingButton" onclick="printPage()" media="print">Print Invoice</button>
   <div class="wrapper">
      <div class="container">
         <div class="row mb-2">
            <img src="../dist/img/hic.png" alt=" Logo-Invoice" class="img-fluid">
         </div>
         <span class="float-right mt-3 mb-2">
            <h4><?= $row_invoice['noinvoice']; ?></h4>
         </span>
         <table class="table table-borderless table-sm">
            <tr>
               <td width="15%">Do Number</td>
               <td width="1%">:</td>
               <td width="30%"><?= $row_invoice['donumber']; ?></td>
               <td></td>
               <td width="15%">Invoice Date</td>
               <td width="1%">:</td>
               <td width="30%"><?= date('d-M-Y', strtotime($row_invoice['invoice_date'])); ?></td>
            </tr>
            <tr>
               <td width="15%">Delivery Date</td>
               <td width="1%">:</td>
               <td width="30%"><?= date('d-M-Y', strtotime($row_invoice['deliverydate'])); ?></td>
               <td></td>
               <td width="15%">Bill To</td>
               <td width="1%">:</td>
               <td width="30%"><?= $row_invoice['nama_customer']; ?></td>
            </tr>
            <tr>
               <td width="15%">Terms</td>
               <td width="1%">:</td>
               <td width="30%"><?= $row_invoice['top']; ?> Days</td>
               <td></td>
               <td width="15%" valign="top">Address</td>
               <td width="1%" valign="top">:</td>
               <td rowspan="4" width="30%" valign="top" class="text-jutify"><?= $row_invoice['alamat']; ?></td>
            </tr>
            <tr>
               <td width="15%">Due Date</td>
               <td width="1%">:</td>
               <td width="30%" colspan="4"><?= date('d-M-Y', strtotime($row_invoice['duedate'])); ?></td>
            </tr>
            <tr>
               <td width="15%">Sales Ref</td>
               <td width="1%">:</td>
               <td width="30%" colspan="4">Muryani</td>
            </tr>
            <tr>
               <td width="15%">Customer PO</td>
               <td width="1%">:</td>
               <td width="30%" colspan="4"><?= $row_invoice['pocustomer']; ?></td>
            </tr>
         </table>
         <table class="table table-sm border-0">
            <thead class="thead-dark">
               <tr class="text-center">
                  <th>#</th>
                  <th>Prod Descriptions</th>
                  <th>Weight</th>
                  <th>Price</th>
                  <th>Disc %</th>
                  <th>Disc Rp</th>
                  <th>Total</th>
               </tr>
            </thead>
            <tbody>
               <?php $no = 1;
               while ($row_invoicedetail = mysqli_fetch_assoc($result_invoicedetail)) { ?>
                  <tr class="text-right">
                     <td class="text-center"><?= $no; ?></td>
                     <td class="text-left"><?= $row_invoicedetail['nmbarang']; ?></td>
                     <td><?= number_format($row_invoicedetail['weight'], 2); ?></td>
                     <td><?= number_format($row_invoicedetail['price'], 2); ?></td>
                     <td class="text-center"><?= $row_invoicedetail['discount']; ?></td>
                     <td><?= number_format($row_invoicedetail['discountrp'], 2); ?></td>
                     <td><?= number_format($row_invoicedetail['amount'], 2); ?></td>
                  </tr>
               <?php $no++;
               } ?>
            </tbody>
            <tfoot class="text-right">
               <tr>
                  <th colspan="2"></th>
                  <th class="thead-light"><?= number_format($row_invoice['xweight'], 2); ?></th>
                  <td colspan="3">Grand Total :</td>
                  <th colspan="3" class="thead-light"><?= number_format($row_invoice['xamount'], 2); ?></th>
               </tr>
               <tr class="border-0">
                  <td colspan="4" rowspan="4" class="text-justify border-0" valign="top">
                     Catatan : <br>
                     <i>
                        <strong>
                           <!-- <?= terbilang($row_invoice['balance']) . " " . "Rupiah"; ?> -->
                           <?= $row_invoice['note']; ?>
                        </strong>
                     </i>
                  </td>
                  <td colspan="2" class="border-0">Tax 11% :</td>
                  <th colspan="3" class="border-0"><?= number_format($row_invoice['tax'], 2); ?></th>
               </tr>
               <tr>
                  <td colspan="2" class="border-0">Charge :</td>
                  <th colspan="3" class="border-0"><?= number_format($row_invoice['charge'], 2); ?></th>
               </tr>
               <tr>
                  <td colspan="2" class="border-0">DownPayment :</td>
                  <th colspan="3" class="border-0"><?= number_format($row_invoice['downpayment'], 2); ?></th>
               </tr>
               <tr>
                  <td colspan="2" class="border-0">Balance :</td>
                  <th colspan="3" class="border-0"><?= number_format($row_invoice['balance'], 2); ?></th>
               </tr>
            </tfoot>
         </table>
         <div class="row">
            <div class="col-4">
               <table class="table table-borderless table-sm">
                  <tr>
                     <th>Payment Methods</th>
                  </tr>
                  <tr>
                     <td colspan="4"><?= $banksegment; ?></td>
                  </tr>
                  <tr>
                     <td>ACC. NAME</td>
                     <td>:</td>
                     <td><strong><?= $accname; ?></strong></td>
                  </tr>
                  <tr>
                     <td>ACC. NUMBER</td>
                     <td>:</td>
                     <td><strong><?= $accnumber; ?></strong></td>
                  </tr>
               </table>
            </div>
            <div class="col-4"></div>
            <div class="col text-center mt-4">
               F I N A N C E
               <br><br><br><br><br>
               ( ............................ )
            </div>
         </div>
      </div>
   </div>
   <script>
      function printPage() {
         window.print();
      }
   </script>
   <script src="../plugins/jquery/jquery.min.js"></script>
   <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
   <script src="../plugins/select2/js/select2.full.min.js"></script>
   <script src="../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
   <script src="../plugins/moment/moment.min.js"></script>
   <script src="../plugins/inputmask/jquery.inputmask.min.js"></script>
   <script src="../plugins/daterangepicker/daterangepicker.js"></script>
   <script src="../plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
   <script src="../plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
   <script src="../plugins/bs-stepper/js/bs-stepper.min.js"></script>
   <script src="../plugins/dropzone/min/dropzone.min.js"></script>
   <script src="../dist/js/adminlte.min.js"></script>
   <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
   <script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
   <script src="../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
   <script src="../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
   <script src="../plugins/jszip/jszip.min.js"></script>
   <script src="../plugins/pdfmake/pdfmake.min.js"></script>
   <script src="../plugins/pdfmake/vfs_fonts.js"></script>
   <script src="../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
   <script src="../plugins/datatables-buttons/js/buttons.print.min.js"></script>


</body>

</html>